Just a small note...
The file from the video was lost and I had
to re-code the entire thing in a couple of
minutes so that people could download this
again properly. As a result, the images that 
were used aren't available in this download.

But, I threw some stuff together for you and 
used some images of landscapes from Google. 
Little did I know the image files were pretty
large and it kind of disrupts the flow of the 
slider the first few times around, but.

DON'T BE DISCOURAGED!

The slider still works perfectly and will
with your images that you are gonna use!

These files are just really big (resolution wise)

Thank you for your understanding and if you're 
reading this, thank you so so so much for watching
my video/s and know that I love you and you're truely
AWESOME! :)
