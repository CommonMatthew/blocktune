<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title></title>
</head>
<body>
	<div class="slider">
		<figure>
			<div class="slide">
				<img src="images/slide_one.jpg">
			</div>

			<div class="slide">
				<img src="images/slide_two.jpg">
			</div>

			<div class="slide">
				<img src="images/slide_three.jpg">
			</div>

			<div class="slide">
				<img src="images/slide_four.jpg">
			</div>

			<div class="slide">
				<img src="images/slide_five.jpg">
			</div>
		</figure>
	</div>
</body>
</html>